import pygame
import sys
import random
from pygame.locals import *
import math

# activate the pygame library
# initiate pygame and give permission
# to use pygame's functionality.
pygame.init()

# define the RGB value for white,
# green, blue colour .


def main():
    clock = pygame.time.Clock()
    FPS = 80

    SCREEN_WIDTH = 1000
    SCREEN_HEIGHT = 1080

    X = SCREEN_WIDTH
    Y = SCREEN_HEIGHT
    green = (0, 255, 0)

    font = pygame.font.SysFont('Arial', 36)
    text = font.render('MISSION SUCCESS', True, green)

    textRect = text.get_rect()
    textRect.center = (X // 2, Y // 2)

    player = pygame.image.load("ufo.png")
    x = 166
    y = 180
    velocity = 12
    direction = True

    pygame_icon = pygame.image.load('checked.png')
    pygame.display.set_icon(pygame_icon)

    #create game window
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("CertifiedSpace")

    #load image
    bg = pygame.image.load("bg.png").convert()
    bg_width = bg.get_width()
    bg_rect = bg.get_rect()

    clock = pygame.time.Clock()
    font = pygame.font.SysFont("Consolas", 22)

    def update_fps():
        fps = str(int(clock.get_fps()))
        fps_text = font.render(fps, 1, pygame.Color("coral"))
        return fps_text


#define game variables

    scroll = 0
    tiles = math.ceil(SCREEN_WIDTH / bg_width) + 1

    #game loop
    run = True
    while run:
        clock.tick(FPS)

        #draw scrolling background
        for i in range(0, tiles):
            screen.blit(bg, (i * bg_width + scroll, 0))
            bg_rect.x = i * bg_width + scroll
            pygame.draw.rect(screen, (255, 0, 0), bg_rect, 1)

            if direction == True:
                screen.blit(player, (x, y))
            if direction == False:
                screen.blit(pygame.transform.flip(player, True, False), (x, y))

        #scroll background
            scroll -= 8
            screen.blit(text, textRect)

            #reset scroll
            if abs(scroll) > bg_width:
                scroll = 0

                #event handler
            clock.tick(FPS)
            screen.blit(update_fps(), (10, 0))
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    run = False
                    # Changing the value of the
                    # direction variable
                    if event.type == pygame.KEYDOWN:
                        if event.key == pygame.K_RIGHT:
                            direction = True
                        elif event.key == pygame.K_LEFT:
                            direction = False

        # Storing the key pressed in a
        # new variable using key.get_pressed()
        # method
            key_pressed_is = pygame.key.get_pressed()

            # Changing the coordinates
            # of the player
            if key_pressed_is[K_LEFT]:
                x -= 5
            if key_pressed_is[K_RIGHT]:
                x += 5
            if key_pressed_is[K_UP]:
                y -= 5
            if key_pressed_is[K_DOWN]:
                y += 5
            if key_pressed_is[K_ESCAPE]:
                sys.exit()
                print("EXITED SUCESSFULLY")
        pygame.display.update()

pygame.quit()

if __name__ == "__main__":
    main()
